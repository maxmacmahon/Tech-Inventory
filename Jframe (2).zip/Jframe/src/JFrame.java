import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.text.JTextComponent;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class JFrame extends javax.swing.JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrame frame = new JFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public JFrame() throws Exception {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(907, 555);
		getContentPane().setLayout(null);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 10, 552, 338);
		getContentPane().add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{new Integer(1), "Lenovo", "Yoga", "Evan O'dll", null},
				{new Integer(2), "Asus", "Chromebook", "Rachel Jacobs", null},
				{new Integer(3), "Asus", "Chromebook", "Madison Osborn", null},
				{new Integer(4), "MacBook", "Air", "Meg", null},
				{new Integer(5), "MacBook", "Pro", "Bri Blanchard", "2014"},
				{new Integer(6), "Asus", "Chromebook", "Byron Peck", null},
				{new Integer(7), "Samsung", "S27E310", "Matt Danner", null},
				{new Integer(8), "Asus", "Chromebook", "Daniel Mahoney", null},
				{new Integer(9), "MacBook", "Air", "Trent McRae", null},
				{new Integer(10), "MacBook", "Pro", "Loren", null},
				{new Integer(11), "MacBook", "Pro", "Bradford", "2018"},
				{new Integer(12), "MacBook", "Pro", "Alyssa B.", null},
				{new Integer(13), "MacBook", "Pro", "Max MacMahon", null},
				{new Integer(14), "MacBook", "Pro", "Connor Best", "2018"},
				{new Integer(15), "MacBook", "Pro", "Brittany", "2018"},
				{new Integer(16), "MacBook", "Pro", "Jess", null},
				{null, "", "", "", null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				"Item", "Brand", "Model", "Owner/Locatoin", "Notes"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton saveButton = new JButton("Save");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int i, j;
				try {						
					
					// save the file to the users home folder
					String userHomeFolder = System.getProperty("user.home");
					File file = new File(userHomeFolder, "TechTable.txt");
					
					if(!file.exists())
						file.createNewFile();
					
					boolean dirCreated = file.mkdir();
					
					//FileWriter fw = new FileWriter(file.getAbsoluteFile());
					BufferedWriter bw = new BufferedWriter(new FileWriter(file));
					
					for(i = 0; i < table_1.getRowCount(); i++) {
						for(j = 0; j <table_1.getColumnCount(); j++) {
							
							if(table_1.getModel().getValueAt(i, j) == null) 
								break;
							else 
								bw.write(table_1.getModel().getValueAt(i, j) + "\t  ");		
						}
				
						// write this for cleanliness
						bw.write("\n__________________________________________________________\n");
					}
					
					bw.close();
					
					// show a message displaying the file saved properly and tell them the location
		            JOptionPane.showMessageDialog(rootPane, "File Saved to " + userHomeFolder + " :D");
				}
				catch(Exception ex) {
					JOptionPane.showMessageDialog(rootPane, "Error Saving :(");
					ex.printStackTrace();
				}
			}
		});
		
		saveButton.setBounds(20, 381, 105, 27);
		getContentPane().add(saveButton);
		table_1.getColumnModel().getColumn(0).setPreferredWidth(46);
		table_1.getColumnModel().getColumn(1).setPreferredWidth(92);
		table_1.getColumnModel().getColumn(2).setPreferredWidth(111);
		table_1.getColumnModel().getColumn(3).setPreferredWidth(105);
		table_1.getColumnModel().getColumn(4).setPreferredWidth(251);
		setVisible(true);
		getContentPane().setBackground(Color.decode("#1b1b1b"));			// color number is used for black
	}
	
}